# Course Registration Application

An elegant, editorial academic workspace for university students to register course interest, manage course offerings, and edit course details with live filtering.

## Layout Composition: Editorial Academic Workspace

The application features a balanced, two-column workspace (maximum width ~1440px) integrated onto a warm canvas (`#F4F3EC`):

1. **Compact Application Header (~110px tall)**:
   - Eyebrow brand label (`Academic Registrar · Course Catalog`)
   - Primary title: `Course Registration` (Manrope) with an editorial one-line subtitle
   - Right-aligned active student identity input (`samira`) that synchronizes globally in real time
2. **Left Catalog Column (~65% width)**:
   - `Available Courses` heading with a citrus count badge
   - Streamlined, integrated `SearchBar` (height 48px, case-sensitive title matching, clear button)
   - Responsive two-column course grid of refined `CourseCard` items positioned right below the header
3. **Right Utility Rail (~35% width, sticky)**:
   - Compact `AddCourseForm` with active student context (`Adding as samira`), clean stacked inputs, and primary submission action
   - `CourseDetails` companion card positioned directly beneath the add form, displaying course details and title editing when a course is selected, or purposeful Stage 6 state treatments

```text
App (Canonical state owner: courses, interest, selection, search, sharedName)
├── Header (Compact editorial banner with editable student identity)
└── Main Workspace (Two-column CSS grid: ~65% catalog / ~35% utility rail)
    ├── Catalog Column
    │   └── CourseList (Integrated header, search bar slot, 2-col course grid, State A/B)
    │       ├── SearchBar (48px input, case-sensitive indicator, clear button)
    │       └── CourseCard (Title, category, student tag, interest checkbox, selected indicator)
    └── Utility Rail (Sticky)
        ├── AddCourseForm (Active identity badge, stacked inputs, prepends course at top)
        └── CourseDetails (Companion card: State C placeholder, State D notice, title editor)
```

## Concepts Implemented Across Stages 1–6

- **Stage 1 (Structure & Data Flow)**: Reusable component breakdown (`Header`, `CourseList`, `CourseCard`), single source of truth in `App`, props passing, and list rendering with stable `key={course.id}` keys.
- **Stage 2 (List Identity & User Choices)**: Independent list item identity using persistent IDs (`course-1`, `course-2`, etc.). Inserting a course at the top shifts list positions without misattaching checkbox choices.
- **Stage 3 (Selection & Editing)**: Storing selection by ID (`selectedCourseId`) and deriving `selectedCourse` directly from canonical `courses`, preventing stale copies. Key-based component reset (`key={selectedCourse.id}`) cleanly syncs edit forms without cascading effects.
- **Stage 4 (Search & Persistence)**: Live, case-sensitive course title search with trimmed whitespace. State ownership of `interestedCourseIds` in `App` preserves user choices when cards unmount during filtering.
- **Stage 5 (Shared Editable Identity)**: A single shared student name (`samira` initially) managed in `App`, editable from the header, and synchronized in real time across the header, course cards, and the add-course form without page reload.
- **Stage 6 (Distinct UI States)**:
  - **State A (Source Empty)**: Displays *"No courses yet"* when `courses.length === 0`.
  - **State B (No Search Matches)**: Displays *"No matching courses"* with a Clear Search button when search yields 0 matches from a non-empty collection.
  - **State C (No Course Selected)**: Displays *"No course selected"* placeholder in the details area when no course is active.
  - **State D (Selected Course Hidden by Filter)**: Displays a clear notice in the details area when the selected course is excluded by the active search filter, coexisting with State B if search matches zero items.

## Commands

```bash
# Install dependencies
npm install

# Start local development server
npm run dev

# Run automated browser test suite (Headless Chrome CDP)
npm test

# Run ESLint validation
npm run lint

# Build production bundle
npm run build

# Preview production build locally
npm run preview
```

## Key Source Files

- [`src/App.jsx`](file:///src/App.jsx): Canonical state manager (`courses`, `interestedCourseIds`, `selectedCourseId`, `searchTerm`, `sharedName`), derivations, and two-column layout coordinator.
- [`src/components/Header.jsx`](file:///src/components/Header.jsx): Compact editorial banner with interactive shared student identity input (`#shared-identity-input`).
- [`src/components/SearchBar.jsx`](file:///src/components/SearchBar.jsx): Compact controlled input for live, case-sensitive title filtering with a clear button.
- [`src/components/AddCourseForm.jsx`](file:///src/components/AddCourseForm.jsx): Compact utility rail form to prepend new courses tagged with the active student identity.
- [`src/components/CourseDetails.jsx`](file:///src/components/CourseDetails.jsx): Companion panel handling State C (no selection), State D (hidden by filter), course info, and title editing.
- [`src/components/CourseList.jsx`](file:///src/components/CourseList.jsx): Catalog section handling State A (source empty), State B (no search matches), integrated search, and the 2-column course grid.
- [`src/components/CourseCard.jsx`](file:///src/components/CourseCard.jsx): Card component presenting course title, category, student tag, selection highlight, and interest checkbox.
- [`src/App.css`](file:///src/App.css): Design system, layout, responsive grid, and custom theme variables.
- [`src/index.css`](file:///src/index.css): Base CSS tokens, resets, typography, and motion preferences.
- [`scripts/test_runner.mjs`](file:///scripts/test_runner.mjs): Chrome DevTools Protocol automation testing Stages 1 through 6, viewports, and console diagnostics.
